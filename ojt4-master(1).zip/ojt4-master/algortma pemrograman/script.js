// STATEMENT DAN VARIABLE
//var nama = "bintang"
//var nilai = 10
//document.write(nama+" dia punya nilai : "+nilai)

// OPERATOR
// var a = 5
// var b = 3
// document.write("Penjumlahan : "+ (a + b))
// document.write("<br>")

// document.write("Pengurangan : "+ (a - b))
// document.write("<br>")

// document.write("Perkalian : "+ (a * b))
// document.write("<br>")

// document.write("Pembagian : "+ (a / b))
// document.write("<br>")

// document.write("Modulus : "+ (a % b))
// document.write("<br>")


// var a = 5
// var b = 3
// document.write(a == b)
// document.write("<br>")

// document.write(a >= b)
// document.write("<br>")

// document.write(a <= b)
// document.write("<br>")

// document.write(a != b)
// document.write("<br>")




// IF ELSE
// nilai = 80
// if (nilai >= 80) {
// 	document.write("A")
// } else {
// 	document.write("B")
// }

// nilai = 50
// if (nilai >= 80) {
// 	document.write("A")
// } else if (nilai >= 60 && nilai < 80) {
// 	document.write("B")
// } else {
// 	document.write("C")
// }

// LOOP
// var n = 0;
// while (n <= 10) {
// 	document.write(n)
// 	document.write("<br>")
// 	n++
// }

// for (var i = 0; i <= 10; i++){
// document.write(i)
// document.write("<br>")
// }


// var data = ["pisang","jeruk","apel","tomat"]
// for (var i = data.length - 1; i >= 0; i--) {
// 	document.write(data[i]) 
// 	document.write("<br>") 
// }










