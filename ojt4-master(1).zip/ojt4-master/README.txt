# Project OJT
- Day 1
Sooftware Development Pengenalan
- Day 2 
UI/UX Penganalan
- Day 3
Cloud Computing
- Day 4 
Dasar2 GO