package main

import "fmt"

func main() {
   nilai := 10
   for i := 0; i <= nilai; i++ {
      fmt.Println(i)
   }

/*   nilai := 79
   if (nilai >= 80) {
      fmt.Println("Selamat Kamu Dapet A")
   } else {
      fmt.Println("Selamat Kamu Dapet B")
   } */


/*   a := 5
   b := 3
   fmt.Println(a == b) //false
   fmt.Println(a >= b) //true
   fmt.Println(a <= b) //false
   fmt.Println(a != b) //true */

/*   a := 5
   b := 3

   fmt.Println(a + b) // 8
   fmt.Println(a - b) // 2
   fmt.Println(a * b) // 15
   fmt.Println(a / b) // 1.666
   fmt.Println(a % b) // 2 */
}